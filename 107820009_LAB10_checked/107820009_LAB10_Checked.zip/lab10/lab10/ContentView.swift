//
//  ContentView.swift
//  lab10
//
//  Created by WUIJUI on 2021/5/26.
//

import SwiftUI
import FirebaseFirestore
import FirebaseFirestoreSwift
struct DoList: Codable,Identifiable{
    @DocumentID var id:String?
    let name:String
    let finish:String
    let date:Date
}
struct ContentView: View {
    @State private var name = ""
    @State private var finish = ""
    @State private var date = Date()
    @State private var valname = "none"
    @State private var valfinish = "none"
    @State private var valdate = Date()
    var body: some View {
        VStack{
            Group{
                Text("ToDo App")
                    .padding()
                HStack{
                    Text("名稱")
                    TextField("請輸入名稱",text:$name)
                }
                HStack{
                    Text("是否完成")
                    TextField("請輸入是／否",text:$finish)
                }
                HStack{
                    Text("到期時間")
                    DatePicker("",selection :$date, displayedComponents:.date)
                }
                Button(action: {createDB()}, label: {
                    Text("新增數據")
                })
            }
            Group{
                Text("目前數據")
                Text("名稱：\(valname)")
                Text("是否完成\(valfinish)")
                Text("時間\(valdate)")
                Button(action:{fetch()} , label: {
                    Text("擷取數據")
                })
            }
        }
        
        
    }
    func fetch() {
        let db = Firestore.firestore()
        db.collection("lab10").getDocuments{
            snapshot, error in
            guard let snapshot = snapshot else {return}
            let data = snapshot.documents.compactMap{snapshot in try? snapshot.data(as: DoList.self)}
            valname = data[0].name
            valfinish = data[0].finish
            valdate = data[0].date
        }
    }
    func createDB(){
        let db = Firestore.firestore()
        let data = DoList( name: name, finish: finish, date: date)
        do {
            let documentReference = try db.collection("lab10").addDocument(from: data)
            print(documentReference.documentID)
        }catch{
            print(error)
        }
    }
}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
