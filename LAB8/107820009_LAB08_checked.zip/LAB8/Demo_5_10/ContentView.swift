//
//  ContentView.swift
//  Demo_5_10
//
//  Created by WUIJUI on 2021/5/10.
//

import SwiftUI

struct ContentView: View {
    @State private var like:Float = 100
    @State private var selectedIndex = 0
    var roles = ["doraemon","pikachu","Dog","cat"]
    @State private var name = ""
    @State private var showAlert = false
    @State private var fine = false
    @State private var date = Date()
    @State private var age = 0

    var body: some View {
        
        VStack{
            Group{
                Text("小叮噹")
                Image("doraemon").clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
            }
            
            
            Stepper("       age:\(age)",onIncrement:{
                age+=1
            },onDecrement:{
                age-=1
            })
            HStack{
                Text("   你有多喜歡")
                Slider(value: $like, in: 0...100)
                Text("\(Int(like))分   ")
            }
            Text("I think \(roles[selectedIndex]) is cuter")
            Picker(selection: $selectedIndex, label: Text("選擇角色")){
                ForEach(roles.indices){
                    (index) in
                    Text(roles[index])
                }
            }
            DatePicker("What's the time?",selection :$date, displayedComponents:.date)
            Text("Today is \(date)")
            HStack{
                Text("      name:   ")
                TextField("輸入名字", text:$name)
            }
            
            HStack{
                Toggle("       How are you?", isOn: $fine)
                if(fine){
                    Text("        \(name) is fine            ")
                }else{
                    Text("       \(name) is not fine            ")
                }
            }
            
            Button(action: {
                showAlert = true
            }, label: {
                Text("submit")
            })
            
        }.alert(isPresented: $showAlert){()->Alert in
            return Alert(title:Text("\(name) gives doraemon \(Int(like)) points, and he likes \(roles[selectedIndex]) the most"))
        }
        
    }
    
    
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
