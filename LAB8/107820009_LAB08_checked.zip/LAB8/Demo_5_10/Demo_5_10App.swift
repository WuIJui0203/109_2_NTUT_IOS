//
//  Demo_5_10App.swift
//  Demo_5_10
//
//  Created by WUIJUI on 2021/5/10.
//

import SwiftUI

@main
struct Demo_5_10App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
