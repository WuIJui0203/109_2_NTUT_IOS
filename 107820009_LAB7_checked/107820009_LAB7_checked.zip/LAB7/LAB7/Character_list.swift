//
//  Character_list.swift
//  LAB7
//
//  Created by WUIJUI on 2021/5/5.
//

import SwiftUI

struct Character_list: View {
    let character:people
    var body: some View {
        NavigationView{
            List(Characters){
                character in NavigationLink(destination: characterDetail(character:character),label:{Rows(character: character)})
                
            }.navigationTitle("角色")
        }
    }
}

struct Character_list_Previews: PreviewProvider {
    static var previews: some View {
        Character_list(character: Characters[0])
    }
}
