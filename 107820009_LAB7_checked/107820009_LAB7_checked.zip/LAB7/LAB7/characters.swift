//
//  characters.swift
//  LAB7
//
//  Created by WUIJUI on 2021/5/5.
//

import Foundation
struct people:Identifiable{
    var id = UUID()
    let name:String
    let discription:String
}
