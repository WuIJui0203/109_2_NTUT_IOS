//
//  ContentView.swift
//  LAB7
//
//  Created by WUIJUI on 2021/5/5.
//

import SwiftUI
let Characters = [people(name: "小智",discription: "神奇寶貝大師"),people(name: "皮卡丘",discription: "可愛")]
struct ContentView: View {
    var body: some View {
        NavigationView{
            VStack{
                Image("主頁面").resizable().scaledToFit().frame(width:350)
                NavigationLink(
                    destination:Character_list(character: Characters[0]),label:{Text("角色清單")}
                )
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
