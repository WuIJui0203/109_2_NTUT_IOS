//
//  Rows.swift
//  LAB7
//
//  Created by WUIJUI on 2021/5/5.
//

import SwiftUI

struct Rows: View {
    let character:people
    var body: some View {
        HStack{
            Image(character.name).resizable().scaledToFill().frame(width:80, height:80).clipped()
            VStack(alignment: .leading){
                Text(character.name)
                Text(character.discription)
            }
            Spacer()
        }
    }
}

struct Rows_Previews: PreviewProvider {
    static var previews: some View {
        Rows(character:people(name: "小智",discription: "神奇寶貝大師")).previewLayout(.fixed(width: 300, height: 70))
    }
}
