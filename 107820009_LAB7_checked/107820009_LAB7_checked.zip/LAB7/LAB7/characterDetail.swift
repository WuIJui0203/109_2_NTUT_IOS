//
//  characteDetail.swift
//  LAB7
//
//  Created by WUIJUI on 2021/5/5.
//

import SwiftUI

struct characterDetail: View {
    let character: people
    var body: some View {
        VStack{
            Image(character.name)
                .resizable()
                .scaledToFill()
                .frame(minWidth:0,maxWidth: .infinity).frame(height: 300).clipped()
            Text(character.discription)
        }.navigationTitle(character.name)
    }
}

struct characterDetail_Previews: PreviewProvider {
    static var previews: some View {
        characterDetail(character: Characters[0])
    }
}
