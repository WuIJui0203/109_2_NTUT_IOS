//
//  ContentView.swift
//  LAB9
//
//  Created by WUIJUI on 2021/5/24.
//

import SwiftUI

struct ContentView: View {
    @StateObject var game = Game()
    var body: some View {
        VStack{
            Text("猜拳遊戲")
            Image("play")
            HStack{
                Text("玩家：  ")
                Image(game.Cplay).resizable().frame(width: 50, height: 50, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                Text(game.Cplay)
            }
            HStack{
                Text("電腦：  ")
                Image(game.Pplay).resizable().frame(width: 50, height: 50, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                Text(game.Pplay)
            }
            HStack{
                Button(action:{game.play()}, label: {
                    Text("\n出拳\n")
                })
            }
            HStack{
                Text("結果：")
                Text(game.State).foregroundColor(.red)
            }
            
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
