//
//  player.swift
//  LAB9
//
//  Created by WUIJUI on 2021/5/24.
//

import Foundation
struct Player{
    var play:String = ""
    var PlayArray = ["paper","scissor","stone"]
    mutating func Player_Play() -> String{
        play = PlayArray[Int.random(in: 0...2)]
        return play
    }}
