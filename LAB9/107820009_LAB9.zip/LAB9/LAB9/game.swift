//
//  game.swift
//  LAB9
//
//  Created by WUIJUI on 2021/5/24.
//

import Foundation
class Game:ObservableObject{
    @Published var Pplay:String = ""
    @Published var State:String = "請按“出拳”開始猜拳"
    @Published var Cplay:String = ""
    var player = Player()
    var computer = Computer()
    func play(){
        Pplay = player.Player_Play()
        Cplay = computer.Cpu_Play()
        if(Pplay == Cplay){
            State = "平手"
        }else if(Pplay == "paper"){
            if(Cplay == "stone"){
                State = "你贏了"
            }else{
                State = "你輸了"
            }
        }else if(Pplay == "scissor"){
            if(Cplay == "paper"){
                State = "你贏了"
            }else{
                State = "你輸了"
            }
        }else if(Pplay == "stone"){
            if(Cplay == "scissor"){
                State = "你贏了"
            }
            else{
                State = "你輸了"
            }
        }
    }
}
