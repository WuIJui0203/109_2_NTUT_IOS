//
//  LAB9App.swift
//  LAB9
//
//  Created by WUIJUI on 2021/5/24.
//

import SwiftUI

@main
struct LAB9App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
